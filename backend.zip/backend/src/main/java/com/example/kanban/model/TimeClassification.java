package com.example.kanban.model;
public enum TimeClassification {
    START_OF_DAY, START_ACTIVITY, PAUSE_BATHROOM, LUNCH, SWITCH_ACTIVITY, END_ACTIVITY, END_OF_DAY, OTHER
}
