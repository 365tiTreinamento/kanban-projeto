package com.example.kanban.model;
public enum Role { OWNER, ADMIN, MEMBER, VIEWER }