package com.example.kanban.model;

import jakarta.persistence.*;
import lombok.*;
import java.time.Instant;

@Entity @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class TimeEntry {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @ManyToOne(fetch = FetchType.LAZY) private Card card;
    @ManyToOne(fetch = FetchType.LAZY) private User user;
    @Enumerated(EnumType.STRING) private TimeClassification classification;
    private Instant startedAt;
    private Instant endedAt;
    private boolean active;
    private String note;
    private String columnNameAtStart;
}
