package com.example.kanban.model;

import jakarta.persistence.*;
import lombok.*;
import java.time.Instant;

@Entity @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class ActivityLog {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private Instant at = Instant.now();
    private String action; // CARD_MOVED, CARD_CREATED, LOGIN, LOGOUT, TIME_START, TIME_PAUSE, TIME_STOP
    private String details;

    @ManyToOne(fetch = FetchType.LAZY)
    private User user;
}
