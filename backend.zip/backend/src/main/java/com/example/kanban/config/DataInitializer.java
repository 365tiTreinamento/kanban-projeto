package com.example.kanban.config;

import com.example.kanban.model.*;
import com.example.kanban.repo.*;
import com.example.kanban.service.UserService;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class DataInitializer {

    @Bean
    CommandLineRunner init(UserService userService, MovementReasonRepo reasonRepo, ProjectRepo projectRepo, KColumnRepo columnRepo) {
        return args -> {
            userService.ensureAdminSeed();
            if (reasonRepo.count() == 0) {
                reasonRepo.save(MovementReason.builder().name("Avanço natural").description("Fluxo normal").build());
                reasonRepo.save(MovementReason.builder().name("Bloqueio").description("Dependência externa").build());
                reasonRepo.save(MovementReason.builder().name("Retrabalho").description("Retorno para correção").build());
            }
            if (projectRepo.count() == 0) {
                Project p = projectRepo.save(Project.builder().name("Projeto Demo").description("Projeto inicial").build());
                columnRepo.save(KColumn.builder().name("Backlog").position(1).project(p).build());
                columnRepo.save(KColumn.builder().name("Em progresso").position(2).project(p).build());
                columnRepo.save(KColumn.builder().name("Revisão").position(3).project(p).build());
                columnRepo.save(KColumn.builder().name("Concluído").position(4).project(p).build());
            }
        };
    }
}
